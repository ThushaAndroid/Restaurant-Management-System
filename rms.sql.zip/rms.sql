-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 19, 2022 at 05:45 AM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rms`
--

-- --------------------------------------------------------

--
-- Table structure for table `amo`
--

DROP TABLE IF EXISTS `amo`;
CREATE TABLE IF NOT EXISTS `amo` (
  `aid` int(3) NOT NULL AUTO_INCREMENT,
  `amount` int(5) NOT NULL,
  PRIMARY KEY (`aid`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `amo`
--

INSERT INTO `amo` (`aid`, `amount`) VALUES
(27, 4000);

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

DROP TABLE IF EXISTS `bill`;
CREATE TABLE IF NOT EXISTS `bill` (
  `bid` int(3) NOT NULL,
  `bfood` varchar(20) NOT NULL,
  `btype` varchar(7) NOT NULL,
  `bprice` int(5) NOT NULL,
  `bqty` int(2) NOT NULL,
  `beprice` int(6) NOT NULL,
  `bdate` date NOT NULL,
  `fprice` int(5) NOT NULL,
  PRIMARY KEY (`bid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`bid`, `bfood`, `btype`, `bprice`, `bqty`, `beprice`, `bdate`, `fprice`) VALUES
(119, 'Kottu', 'Normal', 500, 1, 500, '2022-12-02', 500),
(120, 'Nasi Goreng', 'Full', 1750, 2, 3500, '2022-12-02', 3500);

-- --------------------------------------------------------

--
-- Table structure for table `food`
--

DROP TABLE IF EXISTS `food`;
CREATE TABLE IF NOT EXISTS `food` (
  `fname` varchar(20) NOT NULL,
  `ftype` varchar(6) NOT NULL,
  `fprice` varchar(7) NOT NULL,
  `fid` int(5) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`fid`)
) ENGINE=MyISAM AUTO_INCREMENT=121 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `food`
--

INSERT INTO `food` (`fname`, `ftype`, `fprice`, `fid`) VALUES
('Kottu', 'Normal', '500.0', 119),
('Nasi Goreng', 'Full', '1750.0', 120);

-- --------------------------------------------------------

--
-- Table structure for table `reg`
--

DROP TABLE IF EXISTS `reg`;
CREATE TABLE IF NOT EXISTS `reg` (
  `rname` varchar(50) NOT NULL,
  `rid` varchar(12) NOT NULL,
  `ruser` varchar(10) NOT NULL,
  `rpass` varchar(8) NOT NULL,
  `rrepass` varchar(8) NOT NULL,
  PRIMARY KEY (`rpass`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reg`
--

INSERT INTO `reg` (`rname`, `rid`, `ruser`, `rpass`, `rrepass`) VALUES
('Thushan', '973590286V', 'thushan', '123', '123'),
('kalana', '12346789v', 'kalana', '1234', '123'),
('Dilshan', '991236457V', 'dilshan', '999', '999'),
('nimal', '542452', 'nimal', '111', '111');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
CREATE TABLE IF NOT EXISTS `room` (
  `rname` varchar(20) NOT NULL,
  `rid` varchar(12) NOT NULL,
  `rrnumber` int(2) NOT NULL AUTO_INCREMENT,
  `rpnumber` varchar(10) NOT NULL,
  `raddress` varchar(50) NOT NULL,
  `rdate` date NOT NULL,
  `avb` varchar(4) NOT NULL,
  PRIMARY KEY (`rrnumber`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`rname`, `rid`, `rrnumber`, `rpnumber`, `raddress`, `rdate`, `avb`) VALUES
('Kamal', '4524524', 1, '0253614712', 'kandy', '2022-11-02', 'BOOK'),
('Lahiru', '21546378945', 2, '0123456784', 'kegalle', '2022-11-16', 'BOOK');

-- --------------------------------------------------------

--
-- Table structure for table `stf`
--

DROP TABLE IF EXISTS `stf`;
CREATE TABLE IF NOT EXISTS `stf` (
  `sname` varchar(20) NOT NULL,
  `sphone` varchar(10) NOT NULL,
  `sposition` varchar(20) NOT NULL,
  `ssection` varchar(20) NOT NULL,
  `saddress` varchar(50) NOT NULL,
  `sage` varchar(2) NOT NULL,
  `snic` varchar(12) NOT NULL,
  `sdate` date NOT NULL,
  `sid` int(100) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`sid`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stf`
--

INSERT INTO `stf` (`sname`, `sphone`, `sposition`, `ssection`, `saddress`, `sage`, `snic`, `sdate`, `sid`) VALUES
('Kalana', '0773169720', 'Cook', 'Kitchen Or Food', 'colombo', '20', '973590286V', '1970-01-01', 4),
('Thushan', '0713731530', 'Cook', 'Kitchen Or Food', 'kegalle', '24', '973590286V', '2022-11-07', 8);

-- --------------------------------------------------------

--
-- Table structure for table `tab`
--

DROP TABLE IF EXISTS `tab`;
CREATE TABLE IF NOT EXISTS `tab` (
  `tname` varchar(20) NOT NULL,
  `tpnumber` varchar(10) NOT NULL,
  `tdate` date NOT NULL,
  `tnic` varchar(12) NOT NULL,
  `ttime` varchar(10) NOT NULL,
  `tnumber` int(2) NOT NULL AUTO_INCREMENT,
  `avb` varchar(4) NOT NULL,
  PRIMARY KEY (`tnumber`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tab`
--

INSERT INTO `tab` (`tname`, `tpnumber`, `tdate`, `tnic`, `ttime`, `tnumber`, `avb`) VALUES
('Thushan', '0713731530', '2022-11-09', '973590286V', '10.00 AM', 1, 'BOOK'),
('Lahiru', '0123456123', '1970-01-01', '123456789123', '2.00 PM', 2, 'BOOK');

-- --------------------------------------------------------

--
-- Table structure for table `total`
--

DROP TABLE IF EXISTS `total`;
CREATE TABLE IF NOT EXISTS `total` (
  `bilno` int(3) NOT NULL AUTO_INCREMENT,
  `eprice` int(6) NOT NULL,
  PRIMARY KEY (`bilno`)
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `total`
--

INSERT INTO `total` (`bilno`, `eprice`) VALUES
(1, 3700),
(2, 1900),
(3, 2200),
(4, 3700),
(5, 3500),
(6, 6500),
(7, 6400),
(8, 8450),
(9, 8450),
(10, 8450),
(11, 8450),
(12, 8450),
(13, 8450),
(14, 7850),
(15, 7750),
(16, 6000),
(17, 10150),
(18, 9000),
(19, 4600),
(20, 4750),
(21, 3000),
(22, 6650),
(23, 3500),
(24, 4750),
(25, 4750),
(26, 4750),
(27, 4750),
(28, 4750),
(29, 4750),
(30, 4600),
(31, 1650),
(32, 1250),
(33, 1250),
(34, 1250),
(35, 1250),
(36, 1250),
(37, 1250),
(38, 1000),
(39, 1000),
(40, 1000),
(41, 1000),
(42, 1000),
(43, 1000),
(44, 1000),
(45, 1000),
(46, 1000),
(47, 1000),
(48, 1000),
(49, 1000),
(50, 1000),
(51, 1000),
(52, 1000),
(53, 1000),
(54, 1000),
(55, 1000),
(56, 1000),
(57, 1000),
(58, 3900),
(59, 5750),
(60, 4850),
(61, 4850),
(62, 5900),
(63, 4000);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
